package com.example.planttoseer;

public class plantsearchlist {

    public plantsearchlist() {
    }


    public String getVegimg() {
        return vegimg;
    }

    public void setVegimg(String vegimg) {
        this.vegimg = vegimg;
    }

    public String getVegname() {
        return vegname;
    }

    public void setVegname(String vegname) {
        this.vegname = vegname;
    }

    public String getVegsciname() {
        return vegsciname;
    }

    public void setVegsciname(String vegsciname) {
        this.vegsciname = vegsciname;
    }

    public plantsearchlist(String vegimg, String vegname, String vegsciname) {
        this.vegimg = vegimg;
        this.vegname = vegname;
        this.vegsciname = vegsciname;
    }

    String vegimg;
    String vegname;
    String vegsciname;
}
