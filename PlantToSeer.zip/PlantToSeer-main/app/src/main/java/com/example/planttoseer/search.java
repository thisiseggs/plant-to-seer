package com.example.planttoseer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class search extends AppCompatActivity {
    private Button button;
    //private ImageButton SearchBtn;

    ArrayList<plantsearchlist> list2;
    RecyclerView recyclerView;
    DatabaseReference ref;
    SearchView searchView;
    //AdapterClass helperAdapter;
   //       ListView listData2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_search);
        setContentView(R.layout.search_test);

        ref = FirebaseDatabase.getInstance().getReference().child("Plant").child("vegetable");
        //recyclerView = findViewById(R.id.search_result);
        recyclerView = findViewById(R.id.rv);
        searchView = findViewById(R.id.searchview);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //bottom navigation bar part
        BottomNavigationView bottomNavigationView = findViewById(R.id.btm_navigation);

        //Set home selected
        bottomNavigationView.setSelectedItemId(R.id.nav_home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){

                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext(),Index.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.nav_search:
                        return true;

                    case R.id.nav_insert:
                        startActivity(new Intent(getApplicationContext(),insert.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext(),profile.class));
                        overridePendingTransition(0,0);
                        return true;

                }

                return false;
            }
        });

        // THIS BUTTON USED FOR TESTING THE plant result PAGE
        /*button = (Button) findViewById(R.id.ttesttbutton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentestPage();
            }
        });*/


        Spinner spinner = (Spinner) findViewById(R.id.dropdownsearch);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.search_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);


    }

    @Override
    protected void onStart() {
        super.onStart();
        if (ref != null){
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.exists()){
                        list2 = new ArrayList<>();
                        for(DataSnapshot ds: snapshot.getChildren()){
                            list2.add(ds.getValue(plantsearchlist.class));

                        }
                        AdapterClass adapterClass = new AdapterClass(list2);
                        recyclerView.setAdapter(adapterClass);

                    }

                }


                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(search.this, "database error", Toast.LENGTH_SHORT).show();

                }
            });
        }

        if(searchView != null){
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String s) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String s) {
                    search1(s);
                    return true;
                }
            });
        }

    }

    private void search1(String str){
        ArrayList<plantsearchlist> myList = new ArrayList<>();
        for(plantsearchlist object : list2){
            if(object.getVegname().toLowerCase().contains(str.toLowerCase())){
                myList.add(object);
            }
        }
        AdapterClass adapterClass = new AdapterClass(myList);
        recyclerView.setAdapter(adapterClass);
    }

    //function for button
    /*public void opentestPage() {
        Intent intent = new Intent(this, plantdescription.class);
        startActivity(intent);
    }*/


}