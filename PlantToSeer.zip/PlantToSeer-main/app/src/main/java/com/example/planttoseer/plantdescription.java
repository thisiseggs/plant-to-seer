package com.example.planttoseer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.Serializable;

public class plantdescription extends AppCompatActivity implements Serializable {
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plantdescription);

        //this button go to ontology search page
        button = (Button) findViewById(R.id.gotorelationshipsearchbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openrelaSearchPage();
            }
        });


        //bottom navigation bar part
        BottomNavigationView bottomNavigationView = findViewById(R.id.btm_navigation);

        //Set home selected
        bottomNavigationView.setSelectedItemId(R.id.nav_home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){

                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext(),Index.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.nav_search:
                        startActivity(new Intent(getApplicationContext(),search.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.nav_insert:
                        startActivity(new Intent(getApplicationContext(),insert.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext(),profile.class));
                        overridePendingTransition(0,0);
                        return true;

                }

                return false;
            }
        });


    }

    //function for button
    public void openrelaSearchPage() {
        Intent intent = new Intent(this, relationshipsearch.class);
        startActivity(intent);
    }
}