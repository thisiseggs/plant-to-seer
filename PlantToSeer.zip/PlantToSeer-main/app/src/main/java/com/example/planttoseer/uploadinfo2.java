package com.example.planttoseer;

public class uploadinfo2 {

        public String imageName;
        public String imageURL;
        public uploadinfo2(){}

        public uploadinfo2(String name, String url) {
            this.imageName = name;
            this.imageURL = url;
        }

        public String getImageName() {
            return imageName;
        }
        public String getImageURL() {
            return imageURL;
        }
}
