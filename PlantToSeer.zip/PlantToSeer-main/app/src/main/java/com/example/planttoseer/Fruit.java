package com.example.planttoseer;

public class Fruit {

    private String fruitname, fruitsciname, fruitfamily, fruitfamdesc, fruitdesc, fruitseason,
            fruitvitamin, fruitmineral, fruitharvest, fruitclassification, fruitplanting, fruitsoil,
            fruitsunexposure, fruitwater, fruithumidity, fruitfertilizer;
    private Double fruitsoilph, fruittemp;
    private String spinner2;

    public Fruit() {
    }

    public String getFruitname() {
        return fruitname;
    }

    public void setFruitname(String fruitname) {
        this.fruitname = fruitname;
    }

    public String getFruitsciname() {
        return fruitsciname;
    }

    public void setFruitsciname(String fruitsciname) {
        this.fruitsciname = fruitsciname;
    }

    public String getFruitfamily() {
        return fruitfamily;
    }

    public void setFruitfamily(String fruitfamily) {
        this.fruitfamily = fruitfamily;
    }

    public String getFruitfamdesc() {
        return fruitfamdesc;
    }

    public void setFruitfamdesc(String fruitfamdesc) {
        this.fruitfamdesc = fruitfamdesc;
    }

    public String getFruitdesc() {
        return fruitdesc;
    }

    public void setFruitdesc(String fruitdesc) {
        this.fruitdesc = fruitdesc;
    }

    public String getFruitseason() {
        return fruitseason;
    }

    public void setFruitseason(String fruitseason) {
        this.fruitseason = fruitseason;
    }

    public String getFruitvitamin() {
        return fruitvitamin;
    }

    public void setFruitvitamin(String fruitvitamin) {
        this.fruitvitamin = fruitvitamin;
    }

    public String getFruitmineral() {
        return fruitmineral;
    }

    public void setFruitmineral(String fruitmineral) {
        this.fruitmineral = fruitmineral;
    }

    public String getFruitharvest() {
        return fruitharvest;
    }

    public void setFruitharvest(String fruitharvest) {
        this.fruitharvest = fruitharvest;
    }

    public String getFruitclassification() {
        return fruitclassification;
    }

    public void setFruitclassification(String fruitclassification) {
        this.fruitclassification = fruitclassification;
    }

    public String getFruitplanting() {
        return fruitplanting;
    }

    public void setFruitplanting(String fruitplanting) {
        this.fruitplanting = fruitplanting;
    }

    public String getFruitsoil() {
        return fruitsoil;
    }

    public void setFruitsoil(String fruitsoil) {
        this.fruitsoil = fruitsoil;
    }

    public String getFruitsunexposure() {
        return fruitsunexposure;
    }

    public void setFruitsunexposure(String fruitsunexposure) {
        this.fruitsunexposure = fruitsunexposure;
    }

    public String getFruitwater() {
        return fruitwater;
    }

    public void setFruitwater(String fruitwater) {
        this.fruitwater = fruitwater;
    }

    public String getFruithumidity() {
        return fruithumidity;
    }

    public void setFruithumidity(String fruithumidity) {
        this.fruithumidity = fruithumidity;
    }

    public String getFruitfertilizer() {
        return fruitfertilizer;
    }

    public void setFruitfertilizer(String fruitfertilizer) {
        this.fruitfertilizer = fruitfertilizer;
    }

    public Double getFruitsoilph() {
        return fruitsoilph;
    }

    public void setFruitsoilph(Double fruitsoilph) {
        this.fruitsoilph = fruitsoilph;
    }

    public Double getFruittemp() {
        return fruittemp;
    }

    public void setFruittemp(Double fruittemp) {
        this.fruittemp = fruittemp;
    }

    public String getSpinner2() {
        return spinner2;
    }

    public void setSpinner2(String spinner2) {
        this.spinner2 = spinner2;
    }
}
