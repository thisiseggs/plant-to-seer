package com.example.planttoseer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;

public class insertfruit extends AppCompatActivity {
    private Button button4;
    private Button button5;
    private Button button6;
    private Button btnbrowse1;
    private Button btnupload1;
    private Button btnsave2;
    private Spinner spinner2;
    EditText txtdata2;
    ImageView imgview2;
    Uri FilePathUri2;
    DatabaseReference reference3, reference4;
    StorageReference storageReference3;
    int Image_Request_Code = 7;
    ProgressDialog progressDialog;
    Fruit fruit;

    EditText txtfruitname, txtfruitsciname, txtfruitfamily, txtfruitfamdesc, txtfruitdesc, txtfruitclimatezone,
            txtfruitvitamin, txtfruitmineral, txtfruitharvest, txtfruitclassification, txtfruitplanting, txtfruitsoil, txtfruitsoilph,
            txtfruitsunexposure, txtfruitwater, txtfruittemp, txtfruithumidity, txtfruitfertilizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insertfruit);

        txtfruitname = (EditText)findViewById(R.id.inputfruitname);
        txtfruitsciname = (EditText)findViewById(R.id.inputfruitsciname);
        txtfruitfamily = (EditText)findViewById(R.id.inputfruitfamily);
        txtfruitfamdesc = (EditText)findViewById(R.id.inputfruitfamdesc);
        spinner2 = findViewById(R.id.dropdownplanttype);
        txtfruitdesc = (EditText)findViewById(R.id.inputfruitdesc);
        txtfruitclimatezone = (EditText)findViewById(R.id.inputfruitseason);
        txtfruitvitamin = (EditText)findViewById(R.id.inputfruitvit);
        txtfruitmineral = (EditText)findViewById(R.id.inputfruitmineral);
        txtfruitharvest = (EditText)findViewById(R.id.inputfruitharvest);
        //txtvegclassification = findViewById(R.id.);
        txtfruitplanting = (EditText)findViewById(R.id.inputfruitplanting);
        txtfruitsoil = (EditText)findViewById(R.id.inputfruitsoil);
        txtfruitsoilph = (EditText)findViewById(R.id.inputfruitsoilph);
        txtfruitsunexposure = (EditText)findViewById(R.id.inputfruitsunexposure);
        txtfruitwater = (EditText)findViewById(R.id.inputfruitwater);
        txtfruittemp = (EditText)findViewById(R.id.inputfruittemperature);
        txtfruithumidity = (EditText)findViewById(R.id.inputfruithumidity);
        txtfruitfertilizer = (EditText)findViewById(R.id.inputfruitfertilizer);
        btnsave2 = (Button)findViewById(R.id.fruit_save_button);
        fruit = new Fruit();
        reference3 = FirebaseDatabase.getInstance().getReference().child("Plant").child("Fruit");
        btnsave2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double soilph = Double.parseDouble((txtfruitsoilph.getText().toString().trim())),
                        temp = Double.parseDouble((txtfruittemp.getText().toString().trim()));

                fruit.setFruitname(txtfruitname.getText().toString().trim());
                fruit.setFruitsciname(txtfruitsciname.getText().toString().trim());
                fruit.setFruitfamily(txtfruitfamily.getText().toString().trim());
                fruit.setFruitfamdesc(txtfruitfamdesc.getText().toString().trim());
                fruit.setFruitdesc(txtfruitdesc.getText().toString().trim());
                fruit.setFruitseason(txtfruitclimatezone.getText().toString().trim());
                fruit.setFruitvitamin(txtfruitvitamin.getText().toString().trim());
                fruit.setFruitmineral(txtfruitmineral.getText().toString().trim());
                fruit.setFruitharvest(txtfruitharvest.getText().toString().trim());
                //fruit.setFruitclassification(txtvegclassification.getText().toString().trim());
                fruit.setFruitplanting(txtfruitplanting.getText().toString().trim());
                fruit.setFruitsoil(txtfruitsoil.getText().toString().trim());
                fruit.setFruitsunexposure(txtfruitsunexposure.getText().toString().trim());
                fruit.setFruitwater(txtfruitwater.getText().toString().trim());
                fruit.setFruithumidity(txtfruithumidity.getText().toString().trim());
                fruit.setFruitfertilizer(txtfruitfertilizer.getText().toString().trim());
                fruit.setFruitsoilph(soilph);
                fruit.setFruittemp(temp);
                reference3.push().setValue(fruit);
                Toast.makeText(insertfruit.this, "data inserted sucessfully",Toast.LENGTH_LONG).show();

            }
        });

        storageReference3 = FirebaseStorage.getInstance().getReference("Images");
        reference4 = FirebaseDatabase.getInstance().getReference("Images");
        btnbrowse1 = (Button)findViewById(R.id.btnbrowse1);
        btnupload1= (Button)findViewById(R.id.btnupload1);
        txtdata2 = (EditText)findViewById(R.id.txtdata2);
        imgview2 = (ImageView)findViewById(R.id.imageView4);
        progressDialog = new ProgressDialog(insertfruit.this);// context name as per your project name

        btnbrowse1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Image"), Image_Request_Code);

            }
        });
        btnupload1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


               // UploadImage();

            }
        });

        // THIS BUTTON USED for gotoinsert_fruitbtn button
        button4 = (Button) findViewById(R.id.gotoinsert_vegbtn);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentinservegPage();
            }
        });

        // THIS BUTTON USED for gotoinsert_herbbtn button
        button5 = (Button) findViewById(R.id.gotoinsert_herbbtn);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentinsertherbPage();
            }
        });

        // cancel button
        button6 = (Button) findViewById(R.id.fruit_cancel_button);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentindexPage();
            }
        });

        // browse button
        btnbrowse1 = (Button) findViewById(R.id.btnbrowse1);
        btnbrowse1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentindexPage();
            }
        });

        // upload button
        btnupload1 = (Button) findViewById(R.id.btnupload1);
        btnupload1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentindexPage();
            }
        });

        Spinner spinner = (Spinner) findViewById(R.id.dropdownplanttype);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.planttype_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        //Classification of fruit
        Spinner spinner2 = (Spinner) findViewById(R.id.dropdownfruitclassification);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.fruit_classification_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner2.setAdapter(adapter2);



    } //protected void onCreate(Bundle savedInstanceState)

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Image_Request_Code && resultCode == RESULT_OK && data != null && data.getData() != null) {

            FilePathUri2 = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), FilePathUri2);
                imgview2.setImageBitmap(bitmap);
            }
            catch (IOException e) {

                e.printStackTrace();
            }
        }
    }


    public String GetFileExtension(Uri uri) {

        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri)) ;

    }


    public void UploadImage() {

        if (FilePathUri2 != null) {

            progressDialog.setTitle("Image is Uploading...");
            progressDialog.show();
            StorageReference storageReference4 = storageReference3.child(System.currentTimeMillis() + "." + GetFileExtension(FilePathUri2));
            storageReference4.putFile(FilePathUri2)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                            String TempImageName = txtdata2.getText().toString().trim();
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Image Uploaded Successfully ", Toast.LENGTH_LONG).show();
                            @SuppressWarnings("VisibleForTests")
                            uploadinfo2 imageUploadInfo = new uploadinfo2(TempImageName, taskSnapshot.getUploadSessionUri().toString());
                            String ImageUploadId = reference4.push().getKey();
                            reference4.child(ImageUploadId).setValue(imageUploadInfo);
                        }
                    });
        }
        else {

            Toast.makeText(insertfruit.this, "Please Select Image or Add Image Name", Toast.LENGTH_LONG).show();

        }
    }*/

    //function for gotoinsert_vegbtn button
    public void opentinservegPage() {
        Intent intent = new Intent(this, insert.class);
        startActivity(intent);
    }

    //function for gotoinsert_herbbtn button
    public void opentinsertherbPage() {
        Intent intent = new Intent(this, insertherb.class);
        startActivity(intent);
    }

    //function for cancel button
    public void opentindexPage() {
        Intent intent = new Intent(this, Index.class);
        startActivity(intent);
    }


} //public class insert extends AppCompatActivity