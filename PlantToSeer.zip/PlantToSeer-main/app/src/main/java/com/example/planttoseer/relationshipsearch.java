package com.example.planttoseer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class relationshipsearch extends AppCompatActivity {
    private Button button;
    private Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relationshipsearch);

        //a "Next" button (which go to the ontology search result
        button = (Button) findViewById(R.id.gotorelationshipresultbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openresultPage();
            }
        });

        //a "Back" button (which go to the plant description again
        button1 = (Button) findViewById(R.id.gotoplantdesc);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openplantdescPage();
            }
        });

    }


    //function for button
    public void openresultPage() {
        Intent intent = new Intent(this, relationshipResult.class);
        startActivity(intent);
    }

    //function for button
    public void openplantdescPage() {
        Intent intent = new Intent(this, plantdescription.class);
        startActivity(intent);
    }
}