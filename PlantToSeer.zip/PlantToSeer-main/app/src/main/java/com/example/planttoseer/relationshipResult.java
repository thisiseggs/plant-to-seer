package com.example.planttoseer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class relationshipResult extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relationship_result);
    }
}