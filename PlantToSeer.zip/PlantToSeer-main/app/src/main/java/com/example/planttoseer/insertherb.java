package com.example.planttoseer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.io.IOException;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class insertherb extends AppCompatActivity {
    EditText txtherbname, txtherbsciname, txtherbfamily, txtherbfamdesc, txtherbdesc, txtherbseason,
            txtherbvitamin, txtherbmineral, txtherbharvest, txtherbclassification, txtherbplanting, txtherbsoil, txtherbsoilph,
            txtherbsunexposure, txtherbwater, txtherbtemp, txtherbhumidity, txtherbfertilizer, txtherbtreatment;

    private Button button7;
    private Button button8;
    private Button button9;
    private Button btnbrowse1;
    private Button btnupload1;
    private Button btnsave3;
    private Spinner spinner3;
    EditText txtdata3;
    ImageView imgview3;
    Uri FilePathUri3;
    DatabaseReference reference5, reference6;
    StorageReference storageReference5;
    int Image_Request_Code = 7;
    ProgressDialog progressDialog;
    Herb herb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insertherb);

        txtherbname = (EditText)findViewById(R.id.inputherbname);
        txtherbsciname = (EditText)findViewById(R.id.inputherbsciname);
        txtherbfamily = (EditText)findViewById(R.id.inputherbfamily);
        txtherbfamdesc = (EditText)findViewById(R.id.inputherbfamdesc);
        spinner3 = findViewById(R.id.dropdownplanttype);
        txtherbdesc = (EditText)findViewById(R.id.inputherbdesc);
        txtherbseason = (EditText)findViewById(R.id.inputherbseason);
        txtherbvitamin = (EditText)findViewById(R.id.inputherbvit);
        txtherbmineral = (EditText)findViewById(R.id.inputherbmineral);
        txtherbharvest = (EditText)findViewById(R.id.inputherbharvest);
        //txtvegclassification = findViewById(R.id.);
        txtherbplanting = (EditText)findViewById(R.id.inputherbplanting);
        txtherbsoil = (EditText)findViewById(R.id.inputherbsoil);
        txtherbsoil = (EditText)findViewById(R.id.inputherbsoil);
        txtherbsoilph = (EditText)findViewById(R.id.inputvegsoilph);
        txtherbsunexposure = (EditText)findViewById(R.id.inputherbsunexposure);
        txtherbwater = (EditText)findViewById(R.id.inputherbwater);
        txtherbtemp = (EditText)findViewById(R.id.inputherbtemperature);
        txtherbhumidity = (EditText)findViewById(R.id.inputherbhumidity);
        txtherbfertilizer = (EditText)findViewById(R.id.inputherbfertilizer);
        btnsave3 = (Button)findViewById(R.id.herb_save_button);
        herb = new Herb();
        reference5 = FirebaseDatabase.getInstance().getReference().child("Plant").child("Herb");
        btnsave3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                herb.setHerbname(txtherbname.getText().toString().trim());
                herb.setHerbsciname(txtherbsciname.getText().toString().trim());
                herb.setHerbfamily(txtherbfamily.getText().toString().trim());
                herb.setHerbfamdesc(txtherbfamdesc.getText().toString().trim());
                herb.setHerbdesc(txtherbdesc.getText().toString().trim());
                herb.setHerbseason(txtherbseason.getText().toString().trim());
                herb.setHerbvitamin(txtherbvitamin.getText().toString().trim());
                herb.setHerbmineral(txtherbmineral.getText().toString().trim());
                herb.setHerbharvest(txtherbharvest.getText().toString().trim());
                //herb.setHerbclassification(txtherbclassification.getText().toString().trim());
                herb.setHerbplanting(txtherbplanting.getText().toString().trim());
                herb.setHerbsoil(txtherbsoil.getText().toString().trim());
                herb.setHerbsunexposure(txtherbsunexposure.getText().toString().trim());
                herb.setHerbwater(txtherbwater.getText().toString().trim());
                herb.setHerbhumidity(txtherbhumidity.getText().toString().trim());
                herb.setHerbfertilizer(txtherbfertilizer.getText().toString().trim());
                herb.setHerbtreatment(txtherbtreatment.getText().toString().trim());
                herb.setHerbsoilph(txtherbsoilph.getText().toString().trim());
                herb.setHerbtemp(txtherbtemp.getText().toString().trim());

                reference5.push().setValue(herb);
                Toast.makeText(insertherb.this, "data inserted sucessfully",Toast.LENGTH_LONG).show();

            }
        });

        storageReference5 = FirebaseStorage.getInstance().getReference("Images");
        reference6 = FirebaseDatabase.getInstance().getReference("Images");
        btnbrowse1 = (Button)findViewById(R.id.btnbrowse1);
        btnupload1= (Button)findViewById(R.id.btnupload1);
        txtdata3 = (EditText)findViewById(R.id.txtdata3);
        imgview3 = (ImageView)findViewById(R.id.imageView4);
        progressDialog = new ProgressDialog(insertherb.this);// context name as per your project name

        btnbrowse1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Image"), Image_Request_Code);

            }
        });
        btnupload1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                //UploadImage();

            }
        });


        // THIS BUTTON USED for gotoinsert_fruitbtn button
        button7 = (Button) findViewById(R.id.gotoinsert_fruitbtn);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentinserfruitPage();
            }
        });

        // THIS BUTTON USED for gotoinsert_herbbtn button
        button8 = (Button) findViewById(R.id.gotoinsert_vegbtn);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentinsertvegPage();
            }
        });

        // cancel button
        button8 = (Button) findViewById(R.id.herb_cancel_button);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentindexPage();
            }
        });

        Spinner spinner = (Spinner) findViewById(R.id.dropdownplanttype);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.planttype_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

    } //protected void onCreate(Bundle savedInstanceState)

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Image_Request_Code && resultCode == RESULT_OK && data != null && data.getData() != null) {

            FilePathUri3 = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), FilePathUri3);
                imgview3.setImageBitmap(bitmap);
            }
            catch (IOException e) {

                e.printStackTrace();
            }
        }
    }


    public String GetFileExtension(Uri uri) {

        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri)) ;

    }


    public void UploadImage() {

        if (FilePathUri3 != null) {

            progressDialog.setTitle("Image is Uploading...");
            progressDialog.show();
            StorageReference storageReference6 = storageReference5.child(System.currentTimeMillis() + "." + GetFileExtension(FilePathUri3));
            storageReference6.putFile(FilePathUri3)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                            String TempImageName = txtdata3.getText().toString().trim();
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Image Uploaded Successfully ", Toast.LENGTH_LONG).show();
                            @SuppressWarnings("VisibleForTests")
                            uploadinfo2 imageUploadInfo = new uploadinfo2(TempImageName, taskSnapshot.getUploadSessionUri().toString());
                            String ImageUploadId = reference6.push().getKey();
                            reference6.child(ImageUploadId).setValue(imageUploadInfo);
                        }
                    });
        }
        else {

            Toast.makeText(insertherb.this, "Please Select Image or Add Image Name", Toast.LENGTH_LONG).show();

        }
    }*/

    //function for gotoinsert_fruitbtn button
    public void opentinserfruitPage() {
        Intent intent = new Intent(this, insertfruit.class);
        startActivity(intent);
    }

    //function for gotoinsert_vegbtn button
    public void opentinsertvegPage() {
        Intent intent = new Intent(this, insert.class);
        startActivity(intent);
    }

    //function for cancel button
    public void opentindexPage() {
        Intent intent = new Intent(this, Index.class);
        startActivity(intent);
    }

} //public class insert extends AppCompatActivity