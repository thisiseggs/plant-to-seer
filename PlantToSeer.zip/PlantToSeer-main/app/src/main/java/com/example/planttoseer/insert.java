package com.example.planttoseer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.io.IOException;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class insert extends AppCompatActivity {
    EditText txtvegname, txtvegsciname, txtvegfamily, txtvegfamdesc, txtvegdesc, txtvegseason,
            txtvegvitamin, txtvegmineral, txtvegharvest, txtvegclassification, txtvegplanting, txtvegsoil, txtvegsoilph,
            txtvegsunexposure, txtvegwater, txtvegtemp, txtveghumidity, txtvegfertilizer;

 //   String[] items = {"Herbaceous stem", "Perennial plant", "Shrub", "Climber", "Scandent"};
 //   AutoCompleteTextView autocomplete_txt;
  //  ArrayAdapter<String> adapterItems;
    private Button button1;
    private Button button2;
    private Button button3;
    private Button btnbrowse1;
    private Button btnupload1;
    private Button btnsave1;
    private Spinner spinner1;

    EditText txtdata1;
    ImageView imgview1;
    Uri FilePathUri1;
    DatabaseReference reference1, reference2;
    StorageReference storageReference1;
    int Image_Request_Code = 7;
    ProgressDialog progressDialog;
    Vegetable veg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        txtvegname = (EditText)findViewById(R.id.inputvegname);
        txtvegsciname = (EditText)findViewById(R.id.inputvegsciname);
        txtvegfamily = (EditText)findViewById(R.id.inputvegfamily);
        txtvegfamdesc = (EditText)findViewById(R.id.inputvegfamdesc);
        spinner1 = findViewById(R.id.dropdownplanttype);
        txtvegdesc = (EditText)findViewById(R.id.inputvegdesc);
        txtvegseason = (EditText)findViewById(R.id.inputvegseason);
        txtvegvitamin = (EditText)findViewById(R.id.inputvegvit);
        txtvegmineral = (EditText)findViewById(R.id.inputvegmineral);
        txtvegharvest = (EditText)findViewById(R.id.inputvegharvest);
        //txtvegclassification = findViewById(R.id.);
        txtvegplanting = (EditText)findViewById(R.id.inputvegplanting);
        txtvegsoil = (EditText)findViewById(R.id.inputvegsoil);
        txtvegsoilph = (EditText)findViewById(R.id.inputvegsoilph);
        txtvegsunexposure = (EditText)findViewById(R.id.inputvegsunexposure);
        txtvegwater = (EditText)findViewById(R.id.inputvegwater);
        txtvegtemp = (EditText)findViewById(R.id.inputvegtemperature);
        txtveghumidity = (EditText)findViewById(R.id.inputveghumidity);
        txtvegfertilizer = (EditText)findViewById(R.id.inputvegfertilizer);
        btnsave1 = (Button)findViewById(R.id.veg_save_button);
        veg = new Vegetable();
        //reference1 = FirebaseDatabase.getInstance().getReference().child("Vegetable");
        reference1 = FirebaseDatabase.getInstance().getReference().child("Plant").child("vegetable");
        btnsave1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double soilph = Double.parseDouble((txtvegsoilph.getText().toString().trim())),
                        temp = Double.parseDouble((txtvegtemp.getText().toString().trim()));

                veg.setVegname(txtvegname.getText().toString().trim());
                veg.setVegsciname(txtvegsciname.getText().toString().trim());
                veg.setVegfamily(txtvegfamily.getText().toString().trim());
                veg.setVegfamdesc(txtvegfamdesc.getText().toString().trim());
                veg.setVegdesc(txtvegdesc.getText().toString().trim());
                veg.setVegseason(txtvegseason.getText().toString().trim());
                veg.setVegvitamin(txtvegvitamin.getText().toString().trim());
                veg.setVegmineral(txtvegmineral.getText().toString().trim());
                veg.setVegharvest(txtvegharvest.getText().toString().trim());
                veg.setVegplanting(txtvegplanting.getText().toString().trim());
                veg.setVegsoil(txtvegsoil.getText().toString().trim());
                veg.setVegsunexposure(txtvegsunexposure.getText().toString().trim());
                veg.setVegwater(txtvegwater.getText().toString().trim());
                veg.setVeghumidity(txtveghumidity.getText().toString().trim());
                veg.setVegfertilizer(txtvegfertilizer.getText().toString().trim());
                veg.setVegsoilph(soilph);
                veg.setVegtemp(temp);
                reference1.push().setValue(veg);


                Toast.makeText(insert.this, "data inserted sucessfully",Toast.LENGTH_LONG).show();

            }
        });

        storageReference1 = FirebaseStorage.getInstance().getReference("Images");
        reference2 = FirebaseDatabase.getInstance().getReference("Images");
        btnbrowse1 = (Button)findViewById(R.id.btnbrowse1);
        btnupload1= (Button)findViewById(R.id.btnupload1);
        txtdata1 = (EditText)findViewById(R.id.txtdata1);
        imgview1 = (ImageView)findViewById(R.id.imageView4);
        progressDialog = new ProgressDialog(insert.this);// context name as per your project name

        btnbrowse1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Image"), Image_Request_Code);

            }
        });
        btnupload1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                UploadImage();

            }
        });


        // THIS BUTTON USED for gotoinsert_fruitbtn button
        button1 = (Button) findViewById(R.id.gotoinsert_fruitbtn);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentinserfruitPage();
            }
        });

        // THIS BUTTON USED for gotoinsert_herbbtn button
        button2 = (Button) findViewById(R.id.gotoinsert_herbbtn);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentinsertherbPage();
            }
        });

        // cancel button
        button3 = (Button) findViewById(R.id.veg_cancel_button);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentindexPage();
            }
        });

        // browse button
        btnbrowse1 = (Button) findViewById(R.id.btnbrowse1);
        btnbrowse1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentindexPage();
            }
        });

        // upload button
        btnupload1 = (Button) findViewById(R.id.btnupload1);
        btnupload1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentindexPage();
            }
        });

        //Botanical Habit type
        Spinner spinner = (Spinner) findViewById(R.id.dropdownplanttype);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.planttype_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);


        //Classification of Vegetable
        Spinner spinnerlnw = (Spinner) findViewById(R.id.dropdownvegclassification);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterlnw = ArrayAdapter.createFromResource(this,
                R.array.veg_classification_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinnerlnw.setAdapter(adapterlnw);



    } //protected void onCreate(Bundle savedInstanceState)

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Image_Request_Code && resultCode == RESULT_OK && data != null && data.getData() != null) {

            FilePathUri1 = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), FilePathUri1);
                imgview1.setImageBitmap(bitmap);
            }
            catch (IOException e) {

                e.printStackTrace();
            }
        }
    }


    public String GetFileExtension(Uri uri) {

        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri)) ;

    }


    public void UploadImage() {

        if (FilePathUri1 != null) {

            progressDialog.setTitle("Image is Uploading...");
            progressDialog.show();
            StorageReference storageReference2 = storageReference1.child(System.currentTimeMillis() + "." + GetFileExtension(FilePathUri1));
            storageReference2.putFile(FilePathUri1)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                            String TempImageName = txtdata1.getText().toString().trim();
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Image Uploaded Successfully ", Toast.LENGTH_LONG).show();
                            @SuppressWarnings("VisibleForTests")
                            uploadinfo1 imageUploadInfo = new uploadinfo1(TempImageName, taskSnapshot.getUploadSessionUri().toString());
                            String ImageUploadId = reference2.push().getKey();
                            reference2.child(ImageUploadId).setValue(imageUploadInfo);
                        }
                    });
        }
        else {

            Toast.makeText(insert.this, "Please Select Image or Add Image Name", Toast.LENGTH_LONG).show();

        }
    }


    //function for gotoinsert_fruitbtn button
    public void opentinserfruitPage() {
        Intent intent = new Intent(this, insertfruit.class);
        startActivity(intent);
    }

    //function for gotoinsert_herbbtn button
    public void opentinsertherbPage() {
        Intent intent = new Intent(this, insertherb.class);
        startActivity(intent);
    }

    //function for cancel button
    public void opentindexPage() {
        Intent intent = new Intent(this, Index.class);
        startActivity(intent);
    }



} //public class insert extends AppCompatActivity