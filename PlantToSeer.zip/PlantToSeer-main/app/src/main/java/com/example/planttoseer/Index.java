package com.example.planttoseer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Index extends AppCompatActivity {

    DatabaseReference reference;
    ListView listData1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);

        listData1=(ListView) findViewById(R.id.listData);
        //reference= FirebaseDatabase.getInstance().getReference("vegetable");
        reference= FirebaseDatabase.getInstance().getReference("Plant").child("vegetable");

        ValueEventListener event = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                readData1(snapshot);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        };

        reference.addListenerForSingleValueEvent(event);

        //bottom navigation bar part
        BottomNavigationView bottomNavigationView = findViewById(R.id.btm_navigation);

        //Set home selected
        bottomNavigationView.setSelectedItemId(R.id.nav_home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){

                    case R.id.nav_home:
                        return true;

                    case R.id.nav_search:
                        startActivity(new Intent(getApplicationContext(),search.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.nav_insert:
                        startActivity(new Intent(getApplicationContext(),insert.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext(),profile.class));
                        overridePendingTransition(0,0);
                        return true;

                }

                return false;
            }
        });

    }

    private void readData1(DataSnapshot snapshot) {
        if(snapshot.exists()){
            ArrayList<String> listVeg = new ArrayList<>();

            for(DataSnapshot ds:snapshot.getChildren()){

                Vegetable vegetable = new Vegetable(ds.child("vegname").getValue(String.class),
                        ds.child("vegsciname").getValue(String.class),ds.child("vegfamily").getValue(String.class));
                listVeg.add(vegetable.getVegname()+"\n"+vegetable.getVegsciname()+"\n"+vegetable.getVegfamily());

                /*Plant plant1 = new Plant(ds.child("vegetable").getValue(String.class), ds.child("Fruit").getValue(String.class), ds.child("Herb").getValue(String.class));
                listVeg.add(plant1.getVegname()+"\n"+plant1.getVegsciname()+"\n"+plant1.getVegfamily());*/
            }

            ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,listVeg);
            listData1.setAdapter(arrayAdapter);


        }
        else{
            Log.d("vegetable", "No data Available");
        }
    }

    class Vegetable{


        public Vegetable(String vegname, String vegsciname, String vegfamily) {

            this.vegname = vegname;
            this.vegsciname = vegsciname;
            this.vegfamily = vegfamily;

        }
        public Vegetable() {

        }

        public String getVegname() {
            return vegname;
        }

        public String getVegsciname() {
            return vegsciname;
        }

        public String getVegfamily() {
            return vegfamily;
        }

        public String vegname;
        public String vegsciname;
        public String vegfamily;
    }
}