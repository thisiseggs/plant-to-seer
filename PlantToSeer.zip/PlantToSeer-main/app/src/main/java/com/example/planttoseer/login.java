package com.example.planttoseer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.AuthResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;

public class login extends AppCompatActivity {

    private Button button, loginBtn;
    TextInputEditText loginEmail, loginPassword;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    //FirebaseAuth mAuth;
    //FirebaseAuth.AuthStateListener authListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //get firebase auth instance
        /*mAuth = FirebaseAuth.getInstance();

        //get current user
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();*/

        /*authListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user == null) {
                    // user auth state is changed - user is null
                    // launch login activity
                    startActivity(new Intent(login.this, login.class));
                    finish();
                }
            }
        };*/

        loginEmail = findViewById(R.id.inputemail);
        loginPassword = findViewById(R.id.inputpassword);
        loginBtn = findViewById(R.id.gotoindexbtn);

        //This make the text turned into a button (sign up button)
        TextView tv=(TextView)findViewById(R.id.gotosignupbtn);

        tv.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                opensignupPage();
            }
        });

        //a "proceed" button
        button = (Button) findViewById(R.id.toindexbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get the value
                String email = loginEmail.getEditableText().toString();
                String password = loginPassword.getEditableText().toString();

                if(TextUtils.isEmpty(email) || !email.matches(emailPattern)){
                    loginEmail.setError("Enter proper email");
                }

                else if(TextUtils.isEmpty(password) || password.length() < 6){
                    loginPassword.setError("Enter proper password");
                }

                //check if we have this user that register
                /*else if(mAuth.getCurrentUser() != null) {
                    openindexPage();
                }*/

                //authenticate user
                /*mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                // If sign in fails, display a message to the user. If sign in succeeds
                                // the auth state listener will be notified and logic to handle the
                                // signed in user can be handled in the listener.

                                if (!task.isSuccessful()) {
                                    // there was an error
                                    if (password.length() < 6) {
                                        loginPassword.setError("Enter proper password");
                                    } else {
                                        Toast.makeText(login.this, "Authentication failed", Toast.LENGTH_LONG).show();
                                    }
                                } else {
                                    Intent intent = new Intent(login.this, Index.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                        });*/

                //authenticate user
                /*mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(login.this, new OnCompleteListener<AuthResult>() {}*/
                else{
                    openindexPage();
                }
            }
        });


    }

    /*@Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(authListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (authListener != null) {
            mAuth.removeAuthStateListener(authListener);
        }
    }*/

    //This is function that navigate to sign up if the user doesn't has an account
    public void opensignupPage() {
        Intent intent = new Intent(this, signup.class);
        startActivity(intent);
    }

    //after creating the account then go to index(home)page
    public void openindexPage() {
        Intent intent = new Intent(this, Index.class);
        startActivity(intent);
    }

}