package com.example.planttoseer;

public class Vegetable {
    private String vegname, vegsciname, vegfamily, vegfamdesc, vegdesc, vegseason,
            vegvitamin, vegmineral, vegharvest, vegclassification, vegplanting, vegsoil,
            vegsunexposure, vegwater, veghumidity, vegfertilizer;
    private Double vegsoilph, vegtemp;
    private String spinner1;

    public Vegetable() {

    }

    public String getVegname() {
        return vegname;
    }

    public void setVegname(String vegname) {
        this.vegname = vegname;
    }

    public String getVegsciname() {
        return vegsciname;
    }

    public void setVegsciname(String vegsciname) {
        this.vegsciname = vegsciname;
    }

    public String getVegfamily() {
        return vegfamily;
    }

    public void setVegfamily(String vegfamily) {
        this.vegfamily = vegfamily;
    }

    public String getVegfamdesc() {
        return vegfamdesc;
    }

    public void setVegfamdesc(String vegfamdesc) {
        this.vegfamdesc = vegfamdesc;
    }

    public String getVegdesc() {
        return vegdesc;
    }

    public void setVegdesc(String vegdesc) {
        this.vegdesc = vegdesc;
    }

    public String getVegseason() {
        return vegseason;
    }

    public void setVegseason(String vegseason) {
        this.vegseason = vegseason;
    }

    public String getVegvitamin() {
        return vegvitamin;
    }

    public void setVegvitamin(String vegvitamin) {
        this.vegvitamin = vegvitamin;
    }

    public String getVegmineral() {
        return vegmineral;
    }

    public void setVegmineral(String vegmineral) {
        this.vegmineral = vegmineral;
    }

    public String getVegharvest() {
        return vegharvest;
    }

    public void setVegharvest(String vegharvest) {
        this.vegharvest = vegharvest;
    }

    public String getVegclassification() {
        return vegclassification;
    }

    public void setVegclassification(String vegclassification) {
        this.vegclassification = vegclassification;
    }

    public String getVegplanting() {
        return vegplanting;
    }

    public void setVegplanting(String vegplanting) {
        this.vegplanting = vegplanting;
    }

    public String getVegsoil() {
        return vegsoil;
    }

    public void setVegsoil(String vegsoil) {
        this.vegsoil = vegsoil;
    }

    public String getVegsunexposure() {
        return vegsunexposure;
    }

    public void setVegsunexposure(String vegsunexposure) {
        this.vegsunexposure = vegsunexposure;
    }

    public String getVegwater() {
        return vegwater;
    }

    public void setVegwater(String vegwater) {
        this.vegwater = vegwater;
    }

    public String getVeghumidity() {
        return veghumidity;
    }

    public void setVeghumidity(String veghumidity) {
        this.veghumidity = veghumidity;
    }

    public String getVegfertilizer() {
        return vegfertilizer;
    }

    public void setVegfertilizer(String vegfertilizer) {
        this.vegfertilizer = vegfertilizer;
    }

    public Double getVegsoilph() {
        return vegsoilph;
    }

    public void setVegsoilph(Double vegsoilph) {
        this.vegsoilph = vegsoilph;
    }

    public Double getVegtemp() {
        return vegtemp;
    }

    public void setVegtemp(Double vegtemp) {
        this.vegtemp = vegtemp;
    }

    public String getSpinner1() {
        return spinner1;
    }

    public void setSpinner1(String spinner1) {
        this.spinner1 = spinner1;
    }
}
