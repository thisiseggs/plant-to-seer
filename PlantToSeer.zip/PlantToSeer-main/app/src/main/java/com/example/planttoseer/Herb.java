package com.example.planttoseer;

public class Herb {

    private String herbname, herbsciname, herbfamily, herbfamdesc, herbdesc, herbseason,
            herbvitamin, herbmineral, herbharvest, herbclassification, herbplanting, herbsoil,
            herbsunexposure, herbwater, herbhumidity, herbfertilizer, herbsoilph, herbtemp, herbtreatment;
    private String spinner3;

    public Herb() {
    }

    public String getHerbname() {
        return herbname;
    }

    public void setHerbname(String herbname) {
        this.herbname = herbname;
    }

    public String getHerbsciname() {
        return herbsciname;
    }

    public void setHerbsciname(String herbsciname) {
        this.herbsciname = herbsciname;
    }

    public String getHerbfamily() {
        return herbfamily;
    }

    public void setHerbfamily(String herbfamily) {
        this.herbfamily = herbfamily;
    }

    public String getHerbfamdesc() {
        return herbfamdesc;
    }

    public void setHerbfamdesc(String herbfamdesc) {
        this.herbfamdesc = herbfamdesc;
    }

    public String getHerbdesc() {
        return herbdesc;
    }

    public void setHerbdesc(String herbdesc) {
        this.herbdesc = herbdesc;
    }

    public String getHerbseason() {
        return herbseason;
    }

    public void setHerbseason(String herbseason) {
        this.herbseason = herbseason;
    }

    public String getHerbvitamin() {
        return herbvitamin;
    }

    public void setHerbvitamin(String herbvitamin) {
        this.herbvitamin = herbvitamin;
    }

    public String getHerbmineral() {
        return herbmineral;
    }

    public void setHerbmineral(String herbmineral) {
        this.herbmineral = herbmineral;
    }

    public String getHerbharvest() {
        return herbharvest;
    }

    public void setHerbharvest(String herbharvest) {
        this.herbharvest = herbharvest;
    }

    public String getHerbclassification() {
        return herbclassification;
    }

    public void setHerbclassification(String herbclassification) {
        this.herbclassification = herbclassification;
    }

    public String getHerbplanting() {
        return herbplanting;
    }

    public void setHerbplanting(String herbplanting) {
        this.herbplanting = herbplanting;
    }

    public String getHerbsoil() {
        return herbsoil;
    }

    public void setHerbsoil(String herbsoil) {
        this.herbsoil = herbsoil;
    }

    public String getHerbsunexposure() {
        return herbsunexposure;
    }

    public void setHerbsunexposure(String herbsunexposure) {
        this.herbsunexposure = herbsunexposure;
    }

    public String getHerbwater() {
        return herbwater;
    }

    public void setHerbwater(String herbwater) {
        this.herbwater = herbwater;
    }

    public String getHerbhumidity() {
        return herbhumidity;
    }

    public void setHerbhumidity(String herbhumidity) {
        this.herbhumidity = herbhumidity;
    }

    public String getHerbfertilizer() {
        return herbfertilizer;
    }

    public void setHerbfertilizer(String herbfertilizer) {
        this.herbfertilizer = herbfertilizer;
    }

    public String getHerbsoilph() {
        return herbsoilph;
    }

    public void setHerbsoilph(String herbsoilph) {
        this.herbsoilph = herbsoilph;
    }

    public String getHerbtemp() {
        return herbtemp;
    }

    public void setHerbtemp(String herbtemp) {
        this.herbtemp = herbtemp;
    }

    public String getHerbtreatment() {
        return herbtreatment;
    }

    public void setHerbtreatment(String herbtreatment) {
        this.herbtreatment = herbtreatment;
    }

    public String getSpinner3() {
        return spinner3;
    }

    public void setSpinner3(String spinner3) {
        this.spinner3 = spinner3;
    }
}
