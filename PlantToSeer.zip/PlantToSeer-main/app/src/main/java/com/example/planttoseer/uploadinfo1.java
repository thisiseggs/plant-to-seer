package com.example.planttoseer;

public class uploadinfo1 {

    public String imageName;
    public String imageURL;
    public uploadinfo1(){}

    public uploadinfo1(String name, String url) {
        this.imageName = name;
        this.imageURL = url;
    }

    public String getImageName() {
        return imageName;
    }
    public String getImageURL() {
        return imageURL;
    }
}
