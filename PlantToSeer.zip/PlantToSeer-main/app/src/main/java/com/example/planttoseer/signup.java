package com.example.planttoseer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.internal.api.FirebaseNoSignedInUserException;

public class signup extends AppCompatActivity {
    private Button button, regBtn;
    TextInputEditText regfName, reglName, regEmail, regPhonenum, regPassword;
    //Button regBtn, regToLoginBtn;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    //FirebaseAuth mAuth;
    //FirebaseUser mUser;

    FirebaseDatabase rootNode;
    DatabaseReference reference; //reference to subnodes of loop node or sub element of root node


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //hook to all xml elements in activity_signup.xml
        regfName = findViewById(R.id.inputname);
        reglName = findViewById(R.id.inputsurname);
        regEmail = findViewById(R.id.inputemailaddress);
        regPhonenum = findViewById(R.id.inputphonenum);
        regPassword = findViewById(R.id.inputpass);
        regBtn = findViewById(R.id.gotoindexbtn);
        //RegToLoginBtn = findViewById(R.id.gotologinbtn);
        //mAuth = FirebaseAuth.getInstance();
        //mUser = mAuth.getCurrentUser();

        //This make the text turned into a button (sign up button)
        TextView tv=(TextView)findViewById(R.id.gotologinbtn);

        tv.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                opensignupPage();
            }
        });

        //a "create an account" button
        button = (Button) findViewById(R.id.gotoindexbtn);

        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //rootnode = firebase
                rootNode = FirebaseDatabase.getInstance();
                reference = rootNode.getReference("User");

                //Get all the values

                String firstname = regfName.getEditableText().toString();
                String surname = reglName.getEditableText().toString();
                String email = regEmail.getEditableText().toString();
                String phoneNo = regPhonenum.getEditableText().toString();
                String password = regPassword.getEditableText().toString();

                if(TextUtils.isEmpty(firstname)){
                    regfName.setError("Firstname is required");
                }

                else if(TextUtils.isEmpty(surname)){
                    reglName.setError("Surname is required");
                }

                else if(TextUtils.isEmpty(email) || !email.matches(emailPattern)){
                    regEmail.setError("Enter proper email");
                }

                else if(TextUtils.isEmpty(phoneNo)){
                    regPassword.setError("Phone No. is required");
                }

                else if(TextUtils.isEmpty(password) || password.length() < 6){
                    regPassword.setError("Enter proper password");
                }

                else {

                    UserHelperClass helperClass = new UserHelperClass(firstname, surname, email, phoneNo, password);

                    reference.child(phoneNo).setValue(helperClass);
                    openindexPage();
                }
            }
        });

    }

    /*private void sendUserToNextActivity() {
        Intent intent=new Intent(signup.this, Index.class);
    }

    private void PerforAuth() {
        String email = regEmail.getEditableText().toString();
        String password = regPassword.getEditableText().toString();
    }*/

    //This is function that navigate to sign up if the user doesn't has an account
    public void opensignupPage() {
        Intent intent = new Intent(this, login.class);
        startActivity(intent);
    }


    //after creating the account then go to index(home)page
    public void openindexPage() {
        Intent intent = new Intent(this, Index.class);
        startActivity(intent);
    }

}