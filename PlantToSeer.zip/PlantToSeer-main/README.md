# ข้อมูลโค้ด uxuiเบื้องต้น

- หน้าตาแอพใช้ไฟล์ .xml _(PlantToSeer/app/src/main/res/layout)_ <br>
- อยู่ในส่วนการทำงานใช้ไฟล์ .java _(PlantToSeer/app/src/main/java/com/example/planttoseer)_ <br>
~~ไม่ต้องแปลกใจว่าทำไมแอพไม่ค่อยสวย เพราะใช้จาวาไม่เป็น55555 หน้าตาอะทำได้แต่ทำให้มันใช้งานได้นี่ยากก ก็เลยเลือกอันที่พอจะทำให้มันใช้บานได้;_;~~ <br>
- ไฟล์จาวา เราพยายามคอมเม้นทุกฟังก์ชั่นเอาไว้เพื่อให้ง่ายต่อการเข้าใจและการกลับมาเช็ค

### อันนี้รูปพร้อมชื่อไฟล์ เพราะเราอาจจะตั้งชื่อแปลกนิดหน่อยเลยแคปรูปไว้ให้ดูเป็นภาพรวม
https://github.com/AomHathaichanok/PlantToSeer/blob/main/totaluxui1.PNG <br>
https://github.com/AomHathaichanok/PlantToSeer/blob/main/totaluxui2.PNG <br>
https://github.com/AomHathaichanok/PlantToSeer/blob/main/totaluxui3.PNG <br>


แก้ได้ทุกตรงเลยนะ เลาโอเคถ้ามันเชื่อมกับดาต้าเบสได้ และหากมีคำถามเกี่ยวกับโค้ดที่เค้าทำก็ทักมาถามได้ๆๆๆ
